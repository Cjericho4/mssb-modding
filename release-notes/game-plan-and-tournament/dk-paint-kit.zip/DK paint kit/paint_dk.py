"""Paint two Donkey Kong texture sets from your own original Cloner texture export."""

import argparse
from math import cos, pi
from pathlib import Path
from PIL import Image, ImageDraw

GLOVE = "t05_64x64.png"
MITT_BACK = "t02_64x64.png"
MITT_PALM = "t03_64x64.png"
FUR = "t07_64x64.png"
ATLAS = "t08_128x128.png"
EQUIPMENT = ("Silverback DK", "Golden Glove DK")


def clamp(value):
    return max(0.0, min(1.0, value))


def blend(a, b, amount):
    return tuple(round(x + (y - x) * amount) for x, y in zip(a, b))


def fur_material(stock, grain, silver):
    # The original body wraps this square. Mirrored edges keep our broad tufts
    # continuous through the wrap while fine variations retain the game's shading.
    half = grain.resize((32, 32), Image.Resampling.LANCZOS)
    material = Image.new("L", (64, 64))
    for j in range(2):
        for i in range(2):
            tile = half.transpose(Image.Transpose.FLIP_LEFT_RIGHT) if i else half
            material.paste(
                tile.transpose(Image.Transpose.FLIP_TOP_BOTTOM) if j else tile,
                (i * 32, j * 32),
            )
    lo, mid, hi = (
        ((50, 55, 62), (106, 114, 121), (158, 163, 165))
        if silver
        else ((100, 64, 31), (167, 111, 49), (212, 159, 80))
    )
    out = stock.copy()
    for y in range(64):
        for x in range(64):
            r, g, b, a = stock.getpixel((x, y))
            t = clamp((material.getpixel((x, y)) - 25) / 152 + (r - 94) / 180)
            t = 0.5 + (t - 0.5) * 0.78
            color = (
                blend(lo, mid, clamp(t / 0.48))
                if t < 0.48
                else blend(mid, hi, clamp((t - 0.48) / 0.52))
            )
            out.putpixel((x, y), (*color, a))
    return out


def dye_mitt(stock, silver):
    # Two dedicated islands cover the back and palm of the fielding mitt. Keep
    # the leather's finger seams, creases and patina as we dye the hide.
    shades = (
        ((44, 24, 25), (96, 45, 42), (143, 68, 52), (207, 142, 102))
        if silver
        else ((63, 39, 24), (131, 76, 30), (204, 141, 54), (249, 208, 128))
    )
    out = stock.copy()
    for y in range(stock.height):
        for x in range(stock.width):
            r, g, b, a = stock.getpixel((x, y))
            tone = 0.32 * r + 0.58 * g + 0.10 * b
            if tone < 89:
                color = blend(shades[0], shades[1], clamp((tone - 34) / 55))
            elif tone < 129:
                color = blend(shades[1], shades[2], clamp((tone - 89) / 40))
            else:
                color = blend(shades[2], shades[3], clamp((tone - 129) / 62))
            out.putpixel((x, y), (*color, a))
    return out


def jersey_emblem(silver):
    # Sewn mountain crest or winged baseball. Draw oversize for clean stitching at 48 px.
    zoom = 8
    im = Image.new("RGBA", (48 * zoom, 24 * zoom))
    d = ImageDraw.Draw(im)

    def pts(p):
        return [(round(x * zoom), round(y * zoom)) for x, y in p]

    def poly(p, fill):
        d.polygon(pts(p), fill=fill)

    def line(p, fill, width=1):
        d.line(pts(p), fill=fill, width=round(width * zoom), joint="curve")

    def disk(bounds, fill, outline=None, width=1):
        d.ellipse(
            tuple(round(k * zoom) for k in bounds),
            fill=fill,
            outline=outline,
            width=round(width * zoom),
        )

    if silver:
        # Silver alpine ridges on a wine-and-brass diamond, stitched like a cap badge.
        poly(
            [(2, 13), (12, 10), (23, 1), (35, 10), (46, 13), (24, 23)], (237, 202, 139)
        )
        poly([(5, 13), (13, 11), (23, 3), (34, 11), (43, 13), (24, 21)], (63, 29, 43))
        poly(
            [(10, 14), (17, 8), (20, 10), (24, 5), (28, 10), (31, 8), (37, 14)],
            (238, 236, 215),
        )
        poly([(17, 8), (20, 10), (18, 11), (17, 10), (13, 13)], (150, 170, 176))
        poly([(24, 5), (28, 10), (26, 11), (24, 9), (21, 12)], (150, 170, 176))
        line([(13, 15), (34, 15)], (191, 159, 107), 0.75)
        poly([(18, 17), (30, 17), (24, 20)], (184, 158, 116))
    else:
        # A winged baseball and green stitching against forest canvas.
        for flip in (False, True):

            def wing(p, fill):
                poly([(48 - x if flip else x, y) for x, y in p], fill)

            wing([(2, 6), (19, 8), (18, 16), (11, 15)], (224, 172, 77))
            wing([(3, 6), (18, 8), (18, 10), (6, 9)], (250, 225, 169))
            wing([(7, 11), (18, 12), (18, 14), (10, 13.5)], (250, 225, 169))
            wing([(11, 15), (18, 15.5), (19, 18), (14, 17.5)], (246, 207, 132))
        disk((14, 2, 34, 22), (229, 179, 80))
        disk((15.5, 3.5, 32.5, 20.5), (248, 232, 191), (58, 76, 48), 0.85)
        line([(18, 5.5), (20, 8), (20, 11), (19, 14), (17, 16.5)], (116, 71, 37), 0.9)
        line([(30, 5.5), (28, 8), (28, 11), (29, 14), (31, 16.5)], (116, 71, 37), 0.9)
        for x, y in [(19, 8), (19.8, 11), (18.6, 14), (29, 8), (28.2, 11), (29.4, 14)]:
            line([(x - 1, y + 0.5), (x + 1, y - 0.5)], (116, 71, 37), 0.7)
    return im.resize((48, 24), Image.Resampling.LANCZOS)


def dye_glove(stock, silver):
    # Keep the embossed form and existing laces. Dye the red leather and its insignia.
    dark, mid, light = (
        ((52, 19, 38), (122, 44, 60), (187, 80, 87))
        if silver
        else ((74, 41, 21), (154, 103, 47), (217, 164, 87))
    )
    letters = (238, 215, 163) if silver else (253, 223, 156)
    out = stock.copy()
    for y in range(stock.height):
        for x in range(stock.width):
            r, g, b, a = stock.getpixel((x, y))
            if r < 40 or r < g + 20 or r < b + 27:
                continue
            t = clamp((r - 120) / 116)
            color = (
                blend(dark, mid, clamp(t / 0.53))
                if t < 0.53
                else blend(mid, light, clamp((t - 0.53) / 0.47))
            )
            logo = clamp((g - 0.38 * r) / (0.49 * r))
            out.putpixel((x, y), (*blend(color, letters, logo), a))
    return out


def dye_atlas(stock, body, silver):
    out = stock.copy()
    # Head fur and skin share an island. The skin is more yellow than the fur.
    # Feather the transition at the ear and muzzle while retaining the original details.
    for y in range(96):
        for x in range(64):
            r, g, b, a = stock.getpixel((x, y))
            weight = clamp((0.696 - g / max(1, r)) / 0.18) * clamp((37 - b) / 22)
            if weight:
                color = body.getpixel((x % 64, y % 64))[:3]
                out.putpixel((x, y), (*blend((r, g, b), color, weight), a))
    cloth = (131, 37, 58) if silver else (31, 82, 62)
    for y in range(64):
        for x in range(64, 128):
            if y < 16 and x >= 96:
                continue  # Mouth region
            original = stock.getpixel((x, y))
            # A broad, low-contrast fold survives the game's block compression.
            glow = 0.08 * cos((x - 78) / 54 * pi) + 0.035 * cos((y - 17) / 53 * pi)
            color = tuple(round(v * (1 + glow)) for v in cloth)
            out.putpixel((x, y), (*color, original[3]))
    out.alpha_composite(jersey_emblem(silver), (73, 30))
    return out


def read_template(source, name, size):
    with Image.open(source / name) as file:
        if file.size != size:
            raise ValueError(f"{name}: expected {size[0]} x {size[1]} pixels")
        return file.convert("RGBA")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "source", type=Path, help="original Donkey Kong PNG folder from Export Textures"
    )
    parser.add_argument(
        "destination",
        type=Path,
        help="new folder for Silverback DK and Golden Glove DK",
    )
    args = parser.parse_args()
    if args.destination.exists():
        parser.error("Choose a new destination folder to protect existing paintings.")
    source = args.source.resolve()
    if (
        source == args.destination.resolve()
        or source in args.destination.resolve().parents
    ):
        parser.error("Choose a destination outside the original export.")
    body = read_template(source, FUR, (64, 64))
    atlas = read_template(source, ATLAS, (128, 128))
    glove = read_template(source, GLOVE, (64, 64))
    mitt_back = read_template(source, MITT_BACK, (64, 64))
    mitt_palm = read_template(source, MITT_PALM, (64, 64))
    with Image.open(Path(__file__).with_name("fur-grain.png")) as im:
        grain = im.convert("L")
    args.destination.mkdir(parents=True)
    for name in EQUIPMENT:
        silver = name == EQUIPMENT[0]
        folder = args.destination / name
        folder.mkdir()
        coat = fur_material(body, grain, silver)
        for file, img in [
            (FUR, coat),
            (ATLAS, dye_atlas(atlas, coat, silver)),
            (GLOVE, dye_glove(glove, silver)),
            (MITT_BACK, dye_mitt(mitt_back, silver)),
            (MITT_PALM, dye_mitt(mitt_palm, silver)),
        ]:
            img.save(folder / file, optimize=True)
        print(folder)


if __name__ == "__main__":
    main()
