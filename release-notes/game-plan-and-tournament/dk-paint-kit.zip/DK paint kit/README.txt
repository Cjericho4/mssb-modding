DK showcase paints for MSSB Clone Maker

Silverback DK wears charcoal and silver fur, oxblood leather and a mountain crest.
Golden Glove DK wears honey-gold fur, tan leather and a green tie with a winged baseball.

Make the two texture folders

1. Open your original USA game in Clone Maker. Select Donkey Kong in Studio.
2. Use Export Textures on the character tab. Keep the original PNGs.
3. Install Python 3 and Pillow. If needed, use this command in a Python environment.

       python3 -m pip install Pillow

4. From this kit's folder, run the following. Replace the paths with your
   original export and a new output folder. Keep the quotes around each path.

       python3 paint_dk.py "/path/to/Donkey Kong textures" "/path/to/DK showcase"

   On Windows, use py instead of python3. Output must be outside the original export.
5. In Studio, select a DK clone. Under My textures, choose Silverback DK or
   Golden Glove DK from the new folder. For a team sheet, select a DK portrait
   and add the five PNGs from one folder under Custom textures.

The kit includes the original fur artwork and paint recipe. Each finished pack
contains five painted textures. The recipe uses your own export to preserve
DK's eyes, muzzle, ears and laces. Both packs leave gameplay stats up to you.
